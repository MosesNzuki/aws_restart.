myString = "This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)

name = input("What is your name? ")
print(name)

#f_name = input (" Enter your First Name ")
#m_name = input (" Enter your Middle Name ")
#s_name = input (" Enter your Surname ")
#myName = f_name + " " + m_name + " " + s_name
#print(myName)

color = input("What is your favorite color?  ")
animal = input("What is your favorite animal?  ")
print("{}, you like a {} {}!".format(name,color,animal))

